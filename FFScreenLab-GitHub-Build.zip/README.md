# FF Screen Lab prototype

This is a diagnostic starter project for OnePlus 11R / OxygenOS 16. It does not yet perform true Free Fire image stretching.

## Build an APK on GitHub (no Android Studio needed on your phone)

1. Sign in to GitHub and create a **private** repository named `FFScreenLab`.
2. Upload all files from this project ZIP, including the hidden `.github` folder and its `workflows/build.yml` file. Easiest: extract the ZIP on a computer, then upload the folder contents.
3. Open the repository's **Actions** tab and choose **Build FF Screen Lab APK**.
4. Tap **Run workflow**. Wait for the run to finish.
5. Open the successful run, find **Artifacts**, and download `FFScreenLab-debug-apk`.
6. Extract that artifact ZIP; it contains `app-debug.apk`. Transfer it to your phone and install it.

The workflow builds a debug APK. Review the source before installing. The app uses Shizuku for read-only diagnostics and does not change screen size/density.
