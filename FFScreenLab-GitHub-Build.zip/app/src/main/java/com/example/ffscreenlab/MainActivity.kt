package com.example.ffscreenlab

import android.app.Activity
import android.os.Bundle
import android.graphics.Point
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var output: TextView
    private val requestCode = 7201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "FF Screen Lab — diagnostic prototype"
            textSize = 22f
        }
        output = TextView(this).apply {
            textSize = 14f
            text = "Ready. This prototype does not change resolution or settings."
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        root.addView(title)
        root.addView(button("1. Check Shizuku") { checkShizuku() })
        root.addView(button("2. Read display + Free Fire info") { readDiagnostics() })
        root.addView(button("3. Open Free Fire") {
            val launch = packageManager.getLaunchIntentForPackage("com.dts.freefireth")
            if (launch != null) startActivity(launch)
            else output.text = "Free Fire package com.dts.freefireth was not found."
        })
        val scroll = ScrollView(this)
        scroll.addView(output)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun checkShizuku() {
        if (!Shizuku.pingBinder()) {
            output.text = "Shizuku is not running. Start it, then return here."
            return
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            output.text = "Shizuku permission: granted. You can run read-only diagnostics."
        } else {
            Shizuku.requestPermission(requestCode)
            output.text = "Requested Shizuku permission. Approve the prompt, then retry."
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode) {
            output.text = if (grantResults.isNotEmpty() &&
                grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED)
                "Shizuku permission granted. Run diagnostics."
            else "Shizuku permission denied."
        }
    }

    private fun readDiagnostics() {
        val display = windowManager.defaultDisplay
        val point = Point()
        display.getRealSize(point)
        val density = resources.displayMetrics.densityDpi
        val basic = "Phone display (reported): ${point.x} x ${point.y}\nDensity: ${density} dpi\n"
        if (!Shizuku.pingBinder() ||
            Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            output.text = basic + "\nShizuku not authorized. Tap Check Shizuku first."
            return
        }
        Thread {
            val commands = listOf(
                "wm size",
                "wm density",
                "dumpsys package com.dts.freefireth | grep -i -E 'targetSdk|minSdk|resizeableActivity|maxAspectRatio|minAspectRatio'",
                "cmd package resolve-activity --brief com.dts.freefireth"
            )
            val result = StringBuilder(basic)
            for (cmd in commands) {
                result.append("\n$ ").append(cmd).append("\n")
                try {
                    val p = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
                    val reader = BufferedReader(InputStreamReader(p.inputStream))
                    result.append(reader.readText().take(5000))
                    val err = BufferedReader(InputStreamReader(p.errorStream)).readText()
                    if (err.isNotBlank()) result.append("\n[stderr] ").append(err.take(1000))
                    p.waitFor()
                } catch (e: Exception) {
                    result.append("Error: ").append(e.message)
                }
                result.append("\n")
            }
            runOnUiThread { output.text = result.toString() }
        }.start()
    }
}
